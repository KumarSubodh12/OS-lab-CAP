# OSSim – OS Resource Management Simulator
## Capstone Project Report

### Abstract
OSSim is a menu-driven educational simulator that demonstrates four major operating-system resource-management areas: CPU scheduling, memory allocation, deadlock safety and disk scheduling. It uses Python for algorithms and reporting, and Bash scripts for launch and cleanup integration. Common workloads can be compared using quantitative metrics.

### Problem statement
Operating-system resource managers make decisions about processor time, memory, resource allocation and disk access. Implementing each topic in isolation makes it difficult to understand how the ideas fit into one system. OSSim combines the simulations behind a single menu and produces repeatable output traces and CSV evidence.

### Objectives
1. Implement reusable algorithms for CPU, memory, deadlock and disk management.
2. Provide a single menu-driven workflow.
3. Compare CPU algorithms using the same workload.
4. Validate invalid and boundary inputs.
5. Export reports and log user activity.
6. Use Bash scripts to launch and clean generated output.

### Architecture
`main.py` is the controller. The `modules` package contains independent algorithm modules. `reporting.py` centralizes CSV export and logging. The `data` folder contains sample input. Bash scripts call the Python entry point and clean generated outputs. Unit tests validate core functions.

### Algorithms
- CPU: First Come First Served (FCFS), non-preemptive Shortest Job First (SJF), and Round Robin.
- Memory: First Fit, Best Fit and Worst Fit.
- Deadlock: Banker's safety algorithm computes Need = Maximum − Allocation and searches for a safe process completion sequence.
- Disk: FCFS, Shortest Seek Time First (SSTF), and SCAN.

### Performance measures
For each process:
- Turnaround time = Completion time − Arrival time
- Waiting time = Turnaround time − Burst time
- Response time = First start time − Arrival time

Disk performance is measured by total head movement, the sum of absolute differences between consecutive head positions. Memory output records selected block and remaining capacity.

### Testing
The unit test suite covers correct FCFS waiting times, SJF process completion, Round Robin completion, invalid zero burst time, memory allocation and failed allocation, a safe Banker's state, SSTF ordering and out-of-range disk requests. Run `python -m unittest discover -s tests -v`.

### Sample observations
The included CPU workload is intentionally shared across the CPU algorithms to make comparisons fair. FCFS is simple and has low overhead but may make short jobs wait behind long jobs. SJF can reduce average waiting time when burst lengths are known. Round Robin improves time sharing but its result depends on the time quantum. No single algorithm is optimal for every workload. The memory example demonstrates external fragmentation and failed allocation. Disk algorithms trade request order against head movement.

### Limitations and future scope
The simulator uses deterministic teaching datasets and integer time units. It does not interact with real kernel schedulers or physical storage devices. Future improvements could include preemptive SJF, priority scheduling, paging and page replacement, Banker's request-grant interface, LOOK/C-LOOK disk scheduling, interactive charts and configurable datasets loaded directly from CSV.

### Conclusion
OSSim provides one integrated application for exploring and comparing core OS resource-management algorithms. Its modular design, Bash launch scripts, CSV outputs, logs, tests and documentation make it suitable as a capstone demonstration and a foundation for further development.
